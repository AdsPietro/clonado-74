export interface Informor {
  id: string
  nome: string
  valor: number
  vencimento: string // formato esperado: 'YYYY-MM-DD'
}